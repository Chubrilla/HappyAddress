﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HappyAddress.Data;
using HappyAddress.Models;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace HappyAddress.Controllers
{
    public class AdsController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _environment;
        private const int PageSize = 15;

        public AdsController(AppDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        [HttpGet]
        public IActionResult Create()
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            return View();
        }

        [HttpPost]
        public IActionResult Create(Ad model, List<IFormFile>? imageFiles)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (string.IsNullOrWhiteSpace(model.Title))
            {
                ModelState.AddModelError("Title", "Введите заголовок");
            }

            if (string.IsNullOrWhiteSpace(model.Description))
            {
                ModelState.AddModelError("Description", "Введите описание");
            }

            if (model.Price <= 0)
            {
                ModelState.AddModelError("Price", "Цена должна быть больше 0");
            }

            if (string.IsNullOrWhiteSpace(model.City))
            {
                ModelState.AddModelError("City", "Введите город");
            }

            if (string.IsNullOrWhiteSpace(model.Address))
            {
                ModelState.AddModelError("Address", "Введите адрес");
            }

            if (string.IsNullOrWhiteSpace(model.DealType))
            {
                ModelState.AddModelError("DealType", "Выберите тип сделки");
            }

            if (string.IsNullOrWhiteSpace(model.PropertyType))
            {
                ModelState.AddModelError("PropertyType", "Выберите тип недвижимости");
            }

            if (model.Latitude == null || model.Longitude == null)
            {
                ModelState.AddModelError("", "Выберите точку на карте");
            }

            if (imageFiles != null && imageFiles.Count > 30)
            {
                ModelState.AddModelError("", "Можно загрузить не более 30 фотографий");
            }

            if (imageFiles != null)
            {
                foreach (var imageFile in imageFiles)
                {
                    string extention = Path.GetExtension(imageFile.FileName).ToLower();

                    if (extention != ".jpg" && extention != ".jpeg" && extention != ".png")
                    {
                        ModelState.AddModelError("", "можно загружать фотографии формата JPG или PNG");
                    }

                    if (imageFile.Length > 10 * 1024 * 1024)
                    {
                        ModelState.AddModelError("", "Размер одного фото не должен превышать 10МБ");
                    }
                }
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            model.UserId = userId.Value;
            model.CreatedAt = DateTime.UtcNow;

            _context.Ads.Add(model);
            _context.SaveChanges();

            if (imageFiles != null && imageFiles.Count > 0)
            {
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");

                foreach (var imageFile in imageFiles)
                {
                    if (imageFile != null && imageFile.Length > 0)
                    {
                        string uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            imageFile.CopyTo(stream);
                        }

                        AdImage adImage = new AdImage
                        {
                            AdId = model.Id,
                            ImagePath = "/uploads/" + uniqueFileName
                        };

                        _context.AdImages.Add(adImage);
                    }
                }

                _context.SaveChanges();
            }
            
            TempData["Success"] = "Объявление успешно создано";
            return RedirectToAction("MyAds");
        }

        [HttpGet]
        public IActionResult MyAds(int page = 1)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var query = _context.Ads
                .Where(a => a.UserId == userId.Value)
                .OrderByDescending(a => a.CreatedAt);

            int totalAds = query.Count();
            int totalPages = (int)System.Math.Ceiling((double)totalAds / PageSize);

            var ads = query
                .Skip((page  - 1) * PageSize)
                .Take(PageSize)
                .ToList();

            foreach (var ad in ads)
            {
                ad.Images = _context.AdImages.Where(i => i.AdId == ad.Id).ToList();
            }

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = totalPages;

            return View(ads);
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            var ad = _context.Ads.FirstOrDefault(a => a.Id == id);

            if (ad == null)
            {
                return NotFound();
            }

            ad.Images = _context.AdImages.Where(i => i.AdId == ad.Id).ToList();

            int? userId = HttpContext.Session.GetInt32("UserId");
            
            bool isFavorite = false;
            
            if (userId != null)
            {
                isFavorite = _context.Favorites
                    .Any(f => f.UserId == userId.Value && f.AdId == ad.Id);
            }

            ViewBag.IsFavorite = isFavorite;

            return View(ad);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var ad = _context.Ads.FirstOrDefault(a => a.Id == id && a.UserId == userId.Value);

            if (ad == null)
            {
                return RedirectToAction("Index", "Home");
            }

            ad.Images = _context.AdImages
                .Where(i => i.AdId == ad.Id)
                .ToList();

            return View(ad);
        }

        [HttpPost]
        public IActionResult Edit(Ad model, List<IFormFile>? imageFiles)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var ad = _context.Ads.FirstOrDefault(a => a.Id == model.Id && a.UserId == userId.Value);

            if (ad == null)
            {
                return NotFound();
            }

            if (string.IsNullOrWhiteSpace(model.Title))
            {
                ModelState.AddModelError("Title", "Введите заголовок");
            }

            if (string.IsNullOrWhiteSpace(model.Description))
            {
                ModelState.AddModelError("Description", "Введите описание");
            }

            if (model.Price <= 0)
            {
                ModelState.AddModelError("Price", "Цена должна быть больше 0");
            }

            if (string.IsNullOrWhiteSpace(model.City))
            {
                ModelState.AddModelError("City", "Введите город");
            }

            if (string.IsNullOrWhiteSpace(model.Address))
            {
                ModelState.AddModelError("Address", "Введите адрес");
            }

            if (string.IsNullOrWhiteSpace(model.DealType))
            {
                ModelState.AddModelError("DealType", "Выберите тип сделки");
            }

            if (string.IsNullOrWhiteSpace(model.PropertyType))
            {
                ModelState.AddModelError("PropertyType", "Выберите тип недвижимости");
            }

            if (imageFiles != null && imageFiles.Count > 30)
            {
                ModelState.AddModelError("", "Можно загрузить не более 30 фотографий");
            }

            if (imageFiles != null)
            {
                foreach (var imageFile in imageFiles)
                {
                    string extension = Path.GetExtension(imageFile.FileName).ToLower();

                    if (extension != ".jpg" && extension != ".jpeg" && extension != ".png")
                    {
                        ModelState.AddModelError("", "Можно загружать только JPG или PNG");
                    }

                    if (imageFile.Length > 10 * 1024 * 1024)
                    {
                        ModelState.AddModelError("", "Размер одного фото не должен превышать 10 МБ");
                    }
                }
            }

            if (!ModelState.IsValid)
            {
                model.Images = _context.AdImages.Where(i => i.AdId == model.Id).ToList();
                return View(model);
            }

            ad.Title = model.Title;
            ad.Description = model.Description;
            ad.PhoneNumber = model.PhoneNumber;
            ad.Price = model.Price;
            ad.City = model.City;
            ad.Address = model.Address;
            ad.DealType = model.DealType;
            ad.PropertyType = model.PropertyType;

            _context.SaveChanges();

            if (imageFiles != null && imageFiles.Count > 0)
            {
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");

                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                foreach (var imageFile in imageFiles)
                {
                    if (imageFile != null && imageFile.Length > 0)
                    {
                        string uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            imageFile.CopyTo(stream);
                        }

                        AdImage adImage = new AdImage
                        {
                            AdId = ad.Id,
                            ImagePath = "/uploads/" + uniqueFileName
                        };

                        _context.AdImages.Add(adImage);
                    }
                }

                _context.SaveChanges();
            }
            TempData["Success"] = "Объявление успешно обновлено";
            return RedirectToAction("MyAds");
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var ad = _context.Ads.FirstOrDefault(a => a.Id == id && a.UserId == userId.Value);

            if (ad == null)
            {
                return RedirectToAction("Index", "Home");
            }

            var images = _context.AdImages.Where(i => i.AdId == ad.Id).ToList();

            foreach (var image in images)
            {
                string fullPath = Path.Combine(_environment.WebRootPath, image.ImagePath.TrimStart('/'));

                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }
            }

            _context.AdImages.RemoveRange(images);

            _context.Ads.Remove(ad);
            _context.SaveChanges();

            TempData["Success"] = "Объявление удалено";
            return RedirectToAction("MyAds");
        }

        [HttpPost]
        public IActionResult AddToFavorites(int adId, string? returnUrl = null)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            bool exists = _context.Favorites
                .Any(f => f.UserId == userId.Value && f.AdId == adId);

            if (!exists)
            {
                Favorite favorite = new Favorite
                {
                    UserId = userId.Value,
                    AdId = adId
                };

                _context.Favorites.Add(favorite);
                _context.SaveChanges();

                TempData["Success"] = "Добавлено в избранное";
            }

            if (!string.IsNullOrEmpty(returnUrl))
            {
                return Redirect(returnUrl);
            }

            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public IActionResult RemoveFromFavorites(int adId, string? returnUrl = null)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var favorite = _context.Favorites
                .FirstOrDefault(f => f.UserId == userId.Value && f.AdId == adId);

            if (favorite != null)
            {
                _context.Favorites.Remove(favorite);
                _context.SaveChanges();
                TempData["Success"] = "Объявление удалено из избранного";
            }

            if (!string.IsNullOrEmpty(returnUrl))
            {
                return Redirect(returnUrl);
            }

            return RedirectToAction("Favorites");
        }

        [HttpGet]
        public IActionResult Favorites(int page = 1)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var query = _context.Favorites
                .Where(f => f.UserId == userId.Value)
                .Join(_context.Ads,
                      favorite => favorite.AdId,
                      ad => ad.Id,
                      (favorite, ad) => ad)
                .OrderByDescending(a => a.CreatedAt);

            int totalAds = query.Count();
            int totalPages = (int)System.Math.Ceiling((double)totalAds / PageSize);

            var favoriteAds = query
                .Skip((page - 1) * PageSize)
                .Take(PageSize)
                .ToList();
            foreach (var ad in favoriteAds)
            {
                ad.Images = _context.AdImages.Where(i => i.AdId == ad.Id).ToList();
            }

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = totalPages;

            return View(favoriteAds);            
        }

        [HttpPost]
        public IActionResult DeleteImage(int imageId)
        {
            int? userId = HttpContext.Session.GetInt32("UserId");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var image = _context.AdImages.FirstOrDefault(i => i.Id == imageId);

            if (image == null)
            {
                return NotFound();
            }

            var ad = _context.Ads.FirstOrDefault(a => a.Id == image.AdId);

            if (ad == null || ad.UserId != userId.Value)
            {
                return NotFound();
            }

            string fullPath = Path.Combine(_environment.WebRootPath, image.ImagePath.TrimStart('/').Replace("/", Path.DirectorySeparatorChar.ToString()));

            if (System.IO.File.Exists(fullPath))
            {
                System.IO.File.Delete(fullPath);
            }

            _context.AdImages.Remove(image);
            _context.SaveChanges();

            TempData["Success"] = "Фото удалено";
            return RedirectToAction("Edit", new { id = ad.Id });
        }
    }
}