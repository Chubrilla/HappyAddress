﻿using System.Collections.Generic;

namespace HappyAddress.Models
{
    public class AdFilterViewModel
    {
        public string SearchText { get; set; }

        public string City { get; set; }
        public string DealType { get; set; }
        public string PropertyType { get; set; }

        public decimal? PriceFrom {  get; set; }
        public decimal? PriceTo { get; set; }

        public string SortBy { get; set; }

        public List<Ad> Ads { get; set; } = new List<Ad>();

        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
        public int TotalAds { get; set; }
    }
}