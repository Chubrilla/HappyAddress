﻿using System;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace HappyAddress.Models
{
    public class Ad
    {
        public int Id { get; set; }
        public int UserId { get; set; }

        public string Title { get; set; }
        public string Description { get; set; }

        public decimal Price { get; set; }

        public string City { get; set; }
        public string Address { get; set; }

        public double? Latitude { get; set; }
        public double? Longitude { get; set; }

        public string DealType { get; set; }
        public string PropertyType { get; set; }

        public string Status { get; set; } = "На модерации";
        public string? RejectReason { get; set; }

        public string? ImagePath { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [ValidateNever]
        public User? User { get; set; }

        public string? PhoneNumber { get; set; }

        [ValidateNever]
        public List<AdImage> Images { get; set; } = new List<AdImage>();
    }
}