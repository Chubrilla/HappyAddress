﻿using Microsoft.AspNetCore.Mvc;
using HappyAddress.Data;
using HappyAddress.Models;
using System.Linq;
using System.Globalization;

namespace HappyAddress.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;
        private const int PageSize = 15;

        public HomeController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index(
            string searchText,
            string city,
            string dealType,
            string propertyType,
            decimal? priceFrom,
            decimal? priceTo,
            string sortBy,
            int page = 1)
        {
            var query = _context.Ads
                .Where(a => a.Status == "Опубликовано")
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchText))
            {
                query = query.Where(a =>
                    a.Title.Contains(searchText) ||
                    a.Description.Contains(searchText));
            }

            if (!string.IsNullOrWhiteSpace(city))
            {
                query = query.Where(a => a.City.Contains(city));
            }

            if (!string.IsNullOrWhiteSpace(dealType))
            {
                query = query.Where(a => a.DealType == dealType);
            }

            if (!string.IsNullOrWhiteSpace(propertyType))
            {
                query = query.Where(a => a.PropertyType == propertyType);
            }

            if (priceFrom.HasValue)
            {
                query = query.Where(a => a.Price >= priceFrom.Value);
            }

            if (priceTo.HasValue)
            {
                query = query.Where(a => a.Price <= priceTo.Value);
            }

            switch (sortBy)
            {
                case "price_asc":
                    query = query.OrderBy(a => a.Price);
                    break;

                case "price_desc":
                    query = query.OrderByDescending(a => a.Price);
                    break;

                case "date_asc":
                    query = query.OrderBy(a => a.CreatedAt);
                    break;

                default:
                    query = query.OrderByDescending(a => a.CreatedAt);
                    break;
            }

            int totalAds = query.Count();
            int totalPages = (int)System.Math.Ceiling((double)totalAds / PageSize);

            var ads = query
                .Skip((page - 1) * PageSize)
                .Take(PageSize)
                .ToList();

            var model = new AdFilterViewModel
            {
                City = city,
                DealType = dealType,
                PropertyType = propertyType,
                PriceFrom = priceFrom,
                PriceTo = priceTo,
                SortBy = sortBy,
                Ads = ads,
                CurrentPage = page,
                TotalPages = totalPages,
                TotalAds = totalAds
            };

            foreach (var ad in ads)
            {
                ad.Images = _context.AdImages.Where(i => i.AdId == ad.Id).ToList();
            }

            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}